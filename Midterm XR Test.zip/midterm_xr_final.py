# midterm_xr_final.py
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path

# --- helpers ---
def sha256_hex(b):
    return hashlib.sha256(b).hexdigest()

def kdf(pw, salt, n=150_000, ln=32):
    return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, n, dklen=ln)

def b64e(b):
    return base64.b64encode(b).decode("utf-8")

def b64d(s):
    return base64.b64decode(s.encode("utf-8"))

def xor_bytes(data, key):
    out = bytearray(len(data))
    m = len(key)
    for i, c in enumerate(data):
        out[i] = c ^ key[i % m]
    return bytes(out)

def read_src(text, infile):
    if (text is None) == (infile is None):
        raise ValueError
    if text is not None:
        return text.encode("utf-8")
    return Path(infile).read_bytes()

# --- commands ---
def do_encrypt(a):
    pt = read_src(a.text, a.infile)
    salt = os.urandom(16)
    key = kdf(a.password, salt)
    ct = xor_bytes(pt, key)
    h = sha256_hex(pt)

    
    bundle = {
        "v": 1,          # version
        "s": b64e(salt), # salt (b64)
        "n": 150_000,    # PBKDF2 iterations
        "l": 32,         # key length
        "h": h,          # sha256 of plaintext (hex)
        "ct": b64e(ct)   # ciphertext (b64)
    }

    out = Path(a.out if a.out else "bundle.sbox")
    out.write_text(json.dumps(bundle, indent=2))
    print(f"saved -> {out}")

def do_decrypt(a):
    p = Path(a.bundle)
    if not p.exists():
        print("no such file:", p)
        return

    try:
        b = json.loads(p.read_text())
    except Exception as e:
        print("bad json:", e)
        return

    if b.get("v") != 1:
        print("unsupported version")
        return

    try:
        salt = b64d(b["s"])
        n = int(b["n"])
        ln = int(b["l"])
        ct = b64d(b["ct"])
        key = kdf(a.password, salt, n=n, ln=ln)
    except Exception as e:
        print("bundle fields missing/bad:", e)
        return

    pt = xor_bytes(ct, key)
    ok = "MATCH" if sha256_hex(pt) == b.get("h", "") else "MISMATCH"

    if a.outfile:
        Path(a.outfile).write_bytes(pt)
        print(f"wrote -> {a.outfile}")
    else:
        try:
            print(pt.decode("utf-8"))
        except UnicodeDecodeError:
            print("use --outfile to save)")

    print("integrity:", ok)

# --- cli ---
def make_parser():
    p = argparse.ArgumentParser(description="bundle (xor)")
    sub = p.add_subparsers(dest="cmd")

    e = sub.add_parser("encrypt", help="write a bundle from text/file")
    g = e.add_mutually_exclusive_group(required=True)
    g.add_argument("--text")
    g.add_argument("--infile")
    e.add_argument("--password", required=True)
    e.add_argument("--out", help="output filename (bundle.sbox)")
    e.set_defaults(func=do_encrypt)

    d = sub.add_parser("decrypt", help="open a bundle")
    d.add_argument("--bundle", required=True, help="path to .sbox")
    d.add_argument("--password", required=True)
    d.add_argument("--outfile")
    d.set_defaults(func=do_decrypt)

    return p

def main():
    import sys
    parser = make_parser()
    if len(sys.argv) == 1:
        parser.print_help()
        return
    args = parser.parse_args()
    if hasattr(args, "func"):
        args.func(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
