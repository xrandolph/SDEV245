1. Endpoint returns ID without authentication check. Added authentication "login_required"
2. Returns full account object. require the user to be logged in to ensure only the owner can view account
3. Password hashed with MD5 (no salt) replaced MD5 with bcrypt
4.Password hashed with SHA-1 (no salt)replaced SHA-1 with bcrypt
5.Querie built by string concatenation. Switched from string concatenation to parameterized queries
6.Directly uses request parameter as a query filter. validated usernames
7.Resets password with no required tokens or verification. signed tokens sent to the user’s email, and hashed the new password with bcrypt.
8.loads script without integrity
9.the server will fetch any user supplied url. Added an allowlist of safe domains
10.Compares input password directly to stored value. Stored passwords using bcrypt hashes