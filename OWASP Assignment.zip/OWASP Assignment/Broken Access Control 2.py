from flask import Flask, jsonify, abort, g
from functools import wraps

app = Flask(__name__)
def mock_auth():
    g.current_user = {"id": 5, "is_admin": False}

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        mock_auth()
        if not getattr(g, "current_user", None):
            abort(401)
        return f(*args, **kwargs)
    return wrapped

@app.route('/account/<int:user_id>')
@login_required
def get_account(user_id):
    current = g.current_user
    if current['id'] != user_id and not current.get('is_admin'):
        abort(403)
    account = {"id": user_id, "username": f"user{user_id}", "email": f"user{user_id}@x.com"}
    return jsonify(account)
