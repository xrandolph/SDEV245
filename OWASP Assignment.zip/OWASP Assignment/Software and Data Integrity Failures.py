# secure_cdn.py
from flask import Flask, render_template_string
app = Flask(__name__)

@app.route('/')
def index():
    tpl = '''<!doctype html>
    <html><head>
    <script src="https://cdn.example.com/lib.js"
            integrity="sha384-REPLACE_WITH_REAL_BASE64_HASH"
            crossorigin="anonymous"></script>
    </head><body><h1>Hello</h1></body></html>'''
    return render_template_string(tpl)
