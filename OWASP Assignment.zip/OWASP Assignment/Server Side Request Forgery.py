import requests
from urllib.parse import urlparse
import socket, ipaddress

ALLOWED_HOSTS = {"api.example.com", "public.example.org"}

def is_private_ip(host):
    try:
        for res in socket.getaddrinfo(host, None):
            ip = res[4][0]
            a = ipaddress.ip_address(ip)
            if a.is_private or a.is_loopback or a.is_reserved or a.is_link_local:
                return True
    except Exception:
        return True
    return False

def fetch_url_safe(url):
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError("Invalid scheme")
    host = parsed.hostname
    if host not in ALLOWED_HOSTS:
        raise ValueError("Host not permitted")
    if is_private_ip(host):
        raise ValueError("Resolved to disallowed IP")
    resp = requests.get(url, timeout=5, allow_redirects=False)
    resp.raise_for_status()
    return resp.text
