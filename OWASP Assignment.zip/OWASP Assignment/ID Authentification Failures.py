import bcrypt
import hmac

def check_login(input_password, stored_hash):
    return bcrypt.checkpw(input_password.encode(), stored_hash.encode())

