from flask import Flask, request, url_for, render_template_string, abort
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
import bcrypt

app = Flask(__name__)
app.config['SECRET_KEY'] = 'password'
s = URLSafeTimedSerializer(app.config['SECRET_KEY'])

USER_STORE = {"xavier@gmail.com": {"id": 1, "password_hash": bcrypt.hashpw(b"oldpass", bcrypt.gensalt()).decode()}}

def send_email(to, subject, body):
    print(f"[email to {to}] {subject}\n{body}")

@app.route('/request-password-reset', methods=['POST'])
def request_reset():
    email = request.form['email']
    if email in USER_STORE:
        token = s.dumps(email, salt='password-reset-salt')
        reset_url = url_for('reset_with_token', token=token, _external=True)
        send_email(email, "Password reset", f"Reset link: {reset_url}")
    return "If an account exists, a reset link was sent."

@app.route('/reset/<token>', methods=['GET', 'POST'])
def reset_with_token(token):
    try:
        email = s.loads(token, salt='password-reset-salt', max_age=3600)
    except SignatureExpired:
        abort(400, "Token expired")
    except BadSignature:
        abort(400, "Invalid token")

    if request.method == 'POST':
        new_password = request.form['new_password']
        # validate strength here...
        hashed = bcrypt.hashpw(new_password.encode(), bcrypt.gensalt()).decode()
        USER_STORE[email]['password_hash'] = hashed
        return "Password reset successful"
    # simple form for demo
    return render_template_string('''<form method="post"><input name="new_password" type="password"><button>Reset</button></form>''')
