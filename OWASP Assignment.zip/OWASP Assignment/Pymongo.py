from pymongo import MongoClient
import re

client = MongoClient()
db = client.testdb

USERNAME_RE = re.compile(r'^[A-Za-z0-9_.-]{3,30}$')

def find_user_safe(query_username):
    if not isinstance(query_username, str):
        raise ValueError("Invalid username")
    if not USERNAME_RE.match(query_username):
        raise ValueError("Invalid username format")
    doc = db.users.find_one({"username": query_username}, {"password": 0, "ssn": 0})
    return doc
