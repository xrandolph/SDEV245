from flask import Flask, jsonify, g, request, abort
from functools import wraps

app = Flask(__name__)

def mock_authenticate():
    g.current_user = {"id": 2, "role": "user"}

def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        mock_authenticate()
        if not getattr(g, "current_user", None):
            abort(401)
        return f(*args, **kwargs)
    return wrapped

@app.route('/profile/<int:user_id>')
@login_required
def profile(user_id):
    current = g.current_user
    # authorize: owner or admin only
    if current['id'] != user_id and current.get('role') != 'admin':
        abort(403)

