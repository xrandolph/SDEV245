# secure_sql_param.py
import sqlite3

def get_user_by_username(username):
    conn = sqlite3.connect(':memory:')
    conn.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT);")
    conn.execute("INSERT INTO users (username) VALUES (?)", ("alice",))
    conn.commit()

    sql = "SELECT id, username FROM users WHERE username = ?"
    cur = conn.execute(sql, (username,))
    return cur.fetchall()
